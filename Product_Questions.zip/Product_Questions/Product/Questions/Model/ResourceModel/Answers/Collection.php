<?php
namespace Product\Questions\Model\ResourceModel\Answers;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
   public function _construct()
    {
        $this->_init('Product\Questions\Model\Answers', 'Product\Questions\Model\ResourceModel\Answers');
    }
}
