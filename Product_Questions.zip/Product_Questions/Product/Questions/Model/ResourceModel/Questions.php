<?php
namespace Product\Questions\Model\ResourceModel;

class Questions extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
   
    public function _construct()
    {
        $this->_init('qa_product_questions', 'product_questions_id');
	}
}
