<?php
namespace Product\Questions\Model\ResourceModel\Questions;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
   public function _construct()
    {
        $this->_init('Product\Questions\Model\Questions', 'Product\Questions\Model\ResourceModel\Questions');
    }
}
