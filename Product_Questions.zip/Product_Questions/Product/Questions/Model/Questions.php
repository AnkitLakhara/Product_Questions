<?php

namespace Product\Questions\Model;

use Magento\Framework\Model\AbstractModel;

class Questions extends AbstractModel
{
    public function _construct()
    {
        $this->_init('Product\Questions\Model\ResourceModel\Questions');
    }
}
