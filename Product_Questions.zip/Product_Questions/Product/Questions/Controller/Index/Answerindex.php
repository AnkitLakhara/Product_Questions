<?php

namespace Product\Questions\Controller\Index;
use Magento\Framework\Controller\ResultFactory; 

class Answerindex extends \Magento\Framework\App\Action\Action
{

    public function __construct(
        \Magento\Framework\App\Action\Context $context

    ) {
        parent::__construct($context);
    }   
    public function execute()
    {
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$data = $this->getRequest()->getPostValue();
		//echo "<pre>"; print_r($data); exit;
		$data['status']="pendding";
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();       
		$question = $objectManager->create('Product\Questions\Model\Answers');
		$question->setData($data);
		//$question->setEmail('test@test.com');
		//$question->setQuery('Question Description');
		$question->save();
		$this->messageManager->addSuccess( __('The Answers has been submitted.') );
		//$this->messageManager->addSuccess('Query subbmitted successfully.');
		//$this->_redirect('/question/index/index');
		//return;
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
	}
}
