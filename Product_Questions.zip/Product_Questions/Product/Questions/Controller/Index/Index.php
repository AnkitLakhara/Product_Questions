<?php
namespace Product\Questions\Controller\Index;
use Magento\Framework\Controller\ResultFactory; 

class Index extends \Magento\Framework\App\Action\Action
{
    

    public function __construct(
        \Magento\Framework\App\Action\Context $context
    ) {
	parent::__construct($context);
    }  
	public function execute()
    {
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$data = $this->getRequest()->getPostValue();
		//echo "<pre>"; print_r($data); exit;	
		$data['status']="pendding";
		if(empty($_POST['visibility'])){
			$data['visibility']="public";
		}
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();       
		$question = $objectManager->create('Product\Questions\Model\Questions');
		$question->setData($data);
		$question->save();
		$this->messageManager->addSuccess( __('The Question has been submitted.') );
		//$this->messageManager->addSuccess('Query subbmitted successfully.');
		//$this->_redirect('/question/index/index');
		//return;
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
	}
}

