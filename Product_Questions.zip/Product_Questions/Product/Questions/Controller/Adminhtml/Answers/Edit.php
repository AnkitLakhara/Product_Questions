<?php
/**
 * Copyright © 2015 Company. All rights reserved.
 */

namespace Product\Questions\Controller\Adminhtml\Answers;

class Edit extends \Magento\Backend\App\Action
{
	
    public function execute()
    { // 1. Get ID and create model
        $id = $this->getRequest()->getParam('answers_id');
        $model = $this->_objectManager->create('Product\Questions\Model\Answers');
		$registryObject = $this->_objectManager->get('Magento\Framework\Registry');
        
		// 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This row no longer exists.'));
                $this->_redirect('question/answers/index');
                return;
            }
        }
        // set entered data if was error when we do save
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
		$registryObject->register('qa_product_answers', $model);
		$this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
        
    }
}
