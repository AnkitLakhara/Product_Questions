<?php
namespace Product\Questions\Controller\Adminhtml\Answers;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam(answers_id);
		try {
				$banner = $this->_objectManager->get('Product\Questions\Model\Answers')->load($id);
				$banner->delete();
                $this->messageManager->addSuccess(
                    __('Delete successfully !')
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
	    $this->_redirect('/*/');
    }
}
