<?php
namespace Product\Questions\Controller\Adminhtml\Questions;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{

    
    protected $resultPageFactory;

   
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    

    public function execute()
    {
		
		$this->resultPage = $this->resultPageFactory->create();  
		$this->resultPage->setActiveMenu('Product_Questions::question');
		$this->resultPage ->getConfig()->getTitle()->set((__('Product QA')));
		
		return $this->resultPage;
    }
}
