<?php
namespace Product\Questions\Controller\Adminhtml\Questions;
use Magento\Framework\App\Filesystem\DirectoryList;
class Save extends \Magento\Backend\App\Action
{
 
	public function execute()
    {
		
        $data = $this->getRequest()->getParams();
        if ($data) {
            $model = $this->_objectManager->create('Product\Questions\Model\Questions');
		
            
			$id = $this->getRequest()->getParam('product_questions_id');
            if ($id) {
                $model->load($id);
            }
			
            $model->setData($data);
            
            try {
                $model->save();
                $this->messageManager->addSuccess(__('The Question Has been Saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('question/questions/edit', array('product_questions_id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('question/questions/index');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the question.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('question/questions/edit', array('product_questions_id' => $this->getRequest()->getParam('product_questions_id')));
            return;
        }
        $this->_redirect('question/questions/index');
    }
}
