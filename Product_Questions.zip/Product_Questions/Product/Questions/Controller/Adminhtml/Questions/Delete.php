<?php
namespace Product\Questions\Controller\Adminhtml\Questions;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam('product_questions_id');
		try {
				$banner = $this->_objectManager->get('Product\Questions\Model\Questions')->load($id);
				$banner->delete();
                $this->messageManager->addSuccess(
                    __('Delete successfully !')
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
	    $this->_redirect('/*/');
    }
}
