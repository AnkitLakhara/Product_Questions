<?php
namespace Product\Questions\Controller\Adminhtml\Questions;
use Magento\Framework\Controller\ResultFactory;
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		 $ids = $this->getRequest()->getParam('product_questions_id');
		if (!is_array($ids) || empty($ids)) {
            $this->messageManager->addError(__('Please select question(s).'));
        } else {
            try {
                foreach ($ids as $id) {
                    $row = $this->_objectManager->get('Product\Questions\Model\Questions')->load($id);
					$row->delete();
				}
                $this->messageManager->addSuccess(
                    __('A total of %1 record(s) have been deleted.', count($ids))
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }
		// $this->_redirect('/*/');
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
