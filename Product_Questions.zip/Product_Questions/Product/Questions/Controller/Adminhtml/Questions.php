<?php

namespace Product\Questions\Controller\Adminhtml;

/*use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Review\Model\ReviewFactory;
use Magento\Review\Model\RatingFactory;*/

abstract class Questions extends \Magento\Backend\App\Action
{
	
	/*public function execute()
    {
		echo 'hello';
		exit();
	}*/
    
   protected $_coreRegistry;

   
    protected $resultForwardFactory;

   
    protected $resultPageFactory;

    
    public function _construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_coreRegistry = $coreRegistry;
        parent::_construct($context);
        $this->resultForwardFactory = $resultForwardFactory;
        $this->resultPageFactory = $resultPageFactory;
    }
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu('Product_Questions::questions')->_addBreadcrumb(__('Question'), __('Question'));
        return $this;
    }
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Product_Questions::questions');
    }
}
