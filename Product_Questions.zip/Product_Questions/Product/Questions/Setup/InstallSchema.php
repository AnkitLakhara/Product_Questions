<?php
namespace Product\Questions\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
        $table  = $installer->getConnection()
            ->newTable($installer->getTable('qa_product_questions'))
            ->addColumn(
                'product_questions_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Product Questions Id'
            )
			->addColumn(
                'customer_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Customer Id'
            )
			->addColumn(
                'questions',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Questions'
            )
            ->addColumn(
                'psku',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'psku'
            )
            ->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
				['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                'Created_at'
            )
			 ->addColumn(
                'visibility',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Visibility'
            )
            ->addColumn(
                'product_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Product Id'
            )
			->addColumn(
				'author_name',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Author_Name'
			)
			->addColumn(
				'author_email',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Author_Email'
			)
			->addColumn(
				'asked_from',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Asked_From'
			)
			->addColumn(
				'status',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Status'
			);
        $installer->getConnection()->createTable($table);
		
		$table  = $installer->getConnection()
            ->newTable($installer->getTable('qa_product_answers'))
            ->addColumn(
                'answers_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Answers Id'
            )
			->addColumn(
                'product_questions_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['default' => null],
                'Product Questions Id'
            )
			->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                'Created_at'
            )
			 ->addColumn(
                'customer_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Customer Id'
            )
            ->addColumn(
                'answers',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Answers Id'
            )
            ->addColumn(
                'psku',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'psku'
            )
			->addColumn(
				'author_name',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Author_Name'
			)
			->addColumn(
				'author_email',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Author_Email'
			)
			->addColumn(
				'answers_from',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Answers_from'
			)
			->addColumn(
				'status',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				null,
				['default' => null],
				'Status'
			);
        $installer->getConnection()->createTable($table);
		
		$table  = $installer->getConnection()
            ->newTable($installer->getTable('qa_like_dislikes'))
            ->addColumn(
                'like_dislike_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Like Dislike Id'
            )
			->addColumn(
                'qa_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['nullable' => false, 'default' => '0'],
                'Qa Id'
            )
			->addColumn(
                'customer_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                'Customer Id'
            )
			->addColumn(
                'que_like',
                \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                null,
                ['nullable' => false, 'default' => '0'],
                'Que_Like'
            )
			->addColumn(
                'dislike',
                \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                null,
               ['nullable' => false, 'default' => '0'],
                'Dislike'
            )
			->addColumn(
                'type',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null],
                'Type'
            );
        $installer->getConnection()->createTable($table);
		
        $installer->endSetup();
    }
}
