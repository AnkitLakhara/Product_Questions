<?php
namespace Product\Questions\Block;

class Questions extends \Magento\Framework\View\Element\Template
{
	//protected $_productCollectionFactory;
	protected $_categoryFactory;
	protected $helperData;
	//protected $_customersession;
	
	public function __construct(
	//\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
		\Magento\Catalog\Model\CategoryFactory $categoryFactory,
		\Magento\Framework\View\Element\Template\Context $context,
		\Product\Questions\Model\QuestionsFactory $questionsFactory,
		\Product\Questions\Model\AnswersFactory $answersFactory,
		\Product\Questions\Helper\Data $helperData,
		
	//\Magento\Customer\Model\Session $session
		array $data = array()
	) {
		$this->_categoryFactory = $categoryFactory;
	//  $this->_productCollectionFactory = $productCollectionFactory;
		$this->_questionsFactory = $questionsFactory;
		$this->_answersFactory = $answersFactory;
		$this->helperData = $helperData;
	//$this->_customersession=$session;
		parent::__construct($context, $data);
	}
	public function getUserName()
{
    return $this->helperData->getUserName();
}
	public function getCategoryProduct($categoryId)
	{
		$category = $this->categoryFactory->create()->load($categoryId)->getProductCollection()->addAttributeToSelect('*');
		return $category;
	}
	/*public function sessionCheck()
	{
		return $this->_customersession->isLoggedIn();
	}*/
	public function getAction()
	{
		return __('question/index/index');
	}
	public function getAansweraction()
	{
		return __('question/index/Answerindex');
	}
	
	/*public function getBaseUrl()
	{
	$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
	$resultRedirect->setUrl($this->_redirect->getRefererUrl());
	return $resultRedirect;
	}*/
	public function getCollection(){
		
		/*$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->create('Magento\Customer\Model\Session');
		*/
		$collection = $this->_questionsFactory->create()->getCollection();	
		/*if($customerSession->getCustomer()->getId()){
			
			$collection->addFieldToFilter('customer_id',$customerSession->getCustomer()->getId());	
		}*/
		return $collection;
	}
	
	public function getCollectionAnswers(){
		
		return $this->_answersFactory->create()->getCollection();
		
	}
	public function getProductAnswersCount($productQuestionId){
		
		$answerCollection = $this->_answersFactory->create()->getCollection();
		$answerCollection->addFieldToFilter('product_questions_id',$productQuestionId);
		$answerCollection->addFieldToFilter('status',array('like'=>'approved'));
		return count($answerCollection);
		
	}
	
	public function getProductAnswers($productQuestionId)
	{
		$answerCollection = $this->_answersFactory->create()->getCollection();
		$answerCollection->addFieldToFilter('product_questions_id',$productQuestionId);
		$answerCollection->addFieldToFilter('status',array('like'=>'approved'));
		
		return $answerCollection;
		
	}
	
}
