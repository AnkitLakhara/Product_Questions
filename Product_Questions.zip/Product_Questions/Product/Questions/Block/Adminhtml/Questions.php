<?php //echo "hii";exit;
namespace Product\Questions\Block\Adminhtml;
class Questions extends \Magento\Backend\Block\Widget\Grid\Container
{
	protected function _construct()
	{
		$this->_controller = 'adminhtml_questions';
		$this->_blockGroup = 'Product_Questions';
		$this->_headerText = __('Manage Questions');
		$this->_addButtonLabel = __('New Question');
		parent::_construct();
	}
}