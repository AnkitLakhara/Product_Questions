<?php

namespace Product\Questions\Block\Adminhtml\Questions\Edit\Tab;

/*use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;*/

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{

   	protected $_systemStore;
	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        array $data = array()
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }
	
	protected function _prepareForm()
    {
		/* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('qa_product_questions');
		$isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Product Questions')));

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productCollection  = $objectManager->get('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
        $collection = $productCollection->create()
            ->addAttributeToSelect('*');

        $customerCollection  = $objectManager->get('Magento\Customer\Model\ResourceModel\Customer\CollectionFactory');
            $custcollection = $customerCollection->create()
            ->addAttributeToSelect('*');    
            
        $option[] = array(
            'value' => '',
            'label' => __('-------- Please select a product --------'),
        );
        $custmroption[] = array(
            'value' => '',
            'label' => __('------- Please select a customer -------'),
        );
        foreach ($custcollection as $key=>$customer) {            
            $custmroption[] = array(
                'value' => $customer->getId(),
                'label' => $customer->getName(),
            ); }
        foreach ($collection as $key=>$product) {            
            $option[] = array(
                'value' => $product->getSku(),
                'label' => $product->getName(),
            );}
        
        /*$customerCollection  = $objectManager->get('Magento\Customer\Model\ResourceModel\Customer\CollectionFactory');
            $custcollection = $customerCollection->create()
            ->addAttributeToSelect('*');
        $custmroption[] = array(
              'value' => '',
            'label' => __('-------- Please select a customer --------'),
        );*/
        /*foreach ($custcollection as $key=>$customer) {            
            $custmroption[] = array(
                'value' => $customer->getSku(),
                'label' => $customer->getName(),
            ); }*/
       

        if ($model->getId()) {
            $fieldset->addField('product_questions_id', 'hidden', array('name' => 'product_questions_id'));
        }
        $fieldset->addField(
            'psku',
            'select',
            array(
                'name' => 'psku',
                'values' => $option,
                'label' => __('Select Product'),
                'title' => __('Select Product'),
                'required' => true,
        //'values' => $this->_questionlist->getOptionArray()
            )
        );

        $fieldset->addField(
            'customer_id',
            'select',
            array(
                'name' => 'customer_id',
                'values' => $custmroption,
                'label' => __('Select Customer'),
                'title' => __('Select Customer'),
                'required' => true,
        //'values' => $this->_questionlist->getOptionArray()
            )
        );
		$fieldset->addField(
            'visibility',
            'select',
             array(
                'name' => 'visibility',
                'label' => __('Visibility'),
                'title' => __('Visibility'),
                'required' => true,
		'options'   => 
			array(
				"on" => __('Private'),
				"public" => __('Public')
			),	
            )
        );
		$fieldset->addField(
            'status',
            'select',
            array(
                'name' => 'status',
                'label' => __('Status'),
                'title' => __('Status'),
                'required' => true,
		'options'   => 
			array(
				"approved" => __('Approved'),
				"pendding" => __('Pending'),
			),	
            )
        );
		$fieldset->addField(
            'author_name',
            'text',
            array(
                'name' => 'author_name',
                'label' => __('Author Name'),
                'title' => __('Author Name'),
                'required' => true,
            )
        );
		$fieldset->addField(
            'author_email',
            'text',
            array(
                'name' => 'author_email',
                'label' => __('Author Email'),
                'title' => __('Author Email'),
                'required' => true,
                'class' => 'validate-email',
            )
        );
		$fieldset->addField(
            'questions',
            'text',
            array(
                'name' => 'questions',
                'label' => __('Questions'),
                'title' => __('Questions'),
                'required' => true,
            )
        );
		$fieldset->addField(
            'created_at',
            'date',
            array(
                'name' => 'created_at',
                'label' => __('Created'),
                'title' => __('Created'),
                'date_format' => $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT),
                'time_format' => $this->_localeDate->getTimeFormat(\IntlDateFormatter::SHORT),
                //'class' => 'validate-date'
                'required' => true,
            )
        );
		/*{{CedAddFormField}}*/
	if (!$model->getId()) {
            $model->setData('visibility', $isElementDisabled ? 'private' : 'public');
        }

        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? 'pending' : 'approved');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();   
    }
    public function getTabLabel()
    {
        return __('Question Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Question Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
    
