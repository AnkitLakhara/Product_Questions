<?php
namespace Product\Questions\Block\Adminhtml\Questions;


class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    
    protected $moduleManager;

    protected $_setsFactory;

    protected $_productFactory;

    protected $_type;

    protected $_status;
	protected $_collectionFactory;

    protected $_visibility;

    protected $_websiteFactory;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
		\Product\Questions\Model\ResourceModel\Questions\Collection $collectionFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
		
		$this->_collectionFactory = $collectionFactory;
        $this->_websiteFactory = $websiteFactory;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    protected function _construct()
    {
        parent::_construct();
		
        $this->setId('productGrid');
        $this->setDefaultSort('product_questions_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
       
    }
	protected function _getStore()
    {
        $storeId = (int)$this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }

    protected function _prepareCollection()
    {
		try{
			
			
			$collection =$this->_collectionFactory->load();

		  

			$this->setCollection($collection);

			parent::_prepareCollection();
		  
			return $this;
		}
		catch(Exception $e)
		{
			echo $e->getMessage();die;
		}
    }

     protected function _addColumnFilterToCollection($column)
    {
        if ($this->getCollection()) {
            if ($column->getId() == 'websites') {
                $this->getCollection()->joinField(
                    'websites',
                    'catalog_product_website',
                    'website_id',
                    'product_id=entity_id',
                    null,
                    'left'
                );
            }
        }
        return parent::_addColumnFilterToCollection($column);
    }


    protected function _prepareColumns()
    {
		$this->addColumn(
		    'product_questions_id',
		   array(
		        'header' => __('Id'),
		        //'type' => 'text',
			//'filter_index' => 'rt.product_questions_id',
		        'index' => 'product_questions_id',
		        'header_css_class' => 'col-id',
		        'column_css_class' => 'col-id'
		    )
		);
		 $this->addColumn(
		    'created_at',
		array(
		        'header' => __('Created'),
		        'type' => 'datetime',
			//'filter_index' => 'rt.created_at',
		        'index' => 'created_at',
		        'header_css_class' => 'col-date',
		        'column_css_class' => 'col-date'
				)
		);
		$this->addColumn(
			'author_name',
			array(
			'header'    => __('Author Name'),
			'index'     => 'author_name',
			'class' => 'author_name'
			)
		);
		$this->addColumn(
			'author_email',
			array(
			'header'    => __('Author Mail'),
			'index'     => 'author_email',
			'class' => 'author_email'
			)
		);
		$this->addColumn(
		'questions',
			array(
			'header'    => __('Questions'),
			'index'     => 'questions',
			'class' => 'questions'
			)
		);
		$this->addColumn(
		'visibility',
			array(
			'header'    => __('Visibility'),
			'index'     => 'visibility',
			'type'      => 'options',
			'options'   => 
			array(
				"on" => __('Private'),
				"public" => __('Public')
			),
			)
		);
		$this->addColumn(
		'status',
			array(
			'header'    => __('Status'),
			'index'     => 'status',
			'type'      => 'options',
			'options'   => 
			array(
				"approved" => __('Approved'),
				"pendding" => __('Pending'),
			),
			)
		);
		/*$this->addColumn(
            'action',
            array(
                'header' => __('Action'),
                'type' => 'action',
                'getter' => 'getId',
                'actions' => array(
                    array(
                        'caption' => __('Edit'),
                        'url' => array(
                            'base' => 'question/questions/edit',
                            'params' => array(
                                'productId' => $this->getProductId(),
                                'customerId' => $this->getCustomerId(),
                                //'ret' => $this->_coreRegistry->registry('usePendingFilter') ? 'pending' : null,
                            ),
                        ),
                        'field' => 'id',
                    ),
                ),
                'filter' => false,
                'sortable' => false
            )
        );*/
		/*{{CedAddGridColumn}}*/

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

     /**
     * @return $this
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('product_questions_id');
        $this->getMassactionBlock()->setFormFieldName('product_questions_id');

        $this->getMassactionBlock()->addItem(
            'delete',
            array(
                'label' => __('Delete'),
                'url' => $this->getUrl('question/questions/massDelete'),
                'confirm' => __('Are you sure?')
            )
        );
        return $this;
    }

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('question/*/index', ['_current' => true]);
    }

    public function getRowUrl($row)
    {
        return $this->getUrl(
            'question/questions/edit',
            ['store' => $this->getRequest()->getParam('store'), 'product_questions_id' => $row->getId()]
        );
    }
}
