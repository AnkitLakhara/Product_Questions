<?php

namespace Product\Questions\Block\Adminhtml\Questions;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
	 protected function _construct()
    {
	$this->_objectId = 'product_questions_id';
        $this->_blockGroup = 'Product_Questions';
        $this->_controller = 'adminhtml_questions';

        parent::_construct();
	
        $this->buttonList->update('save', 'label', __('Save Question'));
        $this->buttonList->update('delete', 'label', __('Delete Block'));

        $this->buttonList->add(
            'saveandcontinue',
            array(
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => array(
                    'mage-init' => array('button' => array('event' => 'saveAndContinueEdit', 'target' => '#edit_form'))
                )
            ),
            -100
        );
$this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('block_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'hello_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'hello_content');
                }
            }
        ";
    }
	
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('checkmodule_checkmodel')->getId()) {
            return __("Edit Questions '%1'", $this->escapeHtml($this->_coreRegistry->registry('checkmodule_checkmodel')->getTitle()));
        } else {
            return __('New Questions');
        }
    }
   
}
