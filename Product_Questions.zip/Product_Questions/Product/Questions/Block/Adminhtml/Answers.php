<?php //echo "hii";exit;
namespace Product\Questions\Block\Adminhtml;
class Answers extends \Magento\Backend\Block\Widget\Grid\Container
{
	protected function _construct()
	{
		$this->_controller = 'adminhtml_answers';
		$this->_blockGroup = 'Product_Questions';
		$this->_headerText = __('Manage Answers');
		$this->_addButtonLabel = __('New Answers');
		parent::_construct();
	}
}
