<?php
namespace Product\Questions\Block\Adminhtml\Answers;


class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    
    protected $moduleManager;

    protected $_setsFactory;

    protected $_productFactory;

    protected $_type;

    protected $_status;
	protected $_collectionFactory;

    protected $_visibility;

    protected $_websiteFactory;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
		\Product\Questions\Model\ResourceModel\Answers\Collection $collectionFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
		
	$this->_collectionFactory = $collectionFactory;
        $this->_websiteFactory = $websiteFactory;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

     protected function _construct()
    {
        parent::_construct();
		
        $this->setId('productGrid');
        $this->setDefaultSort('answers_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
       
    }
	protected function _getStore()
    {
        $storeId = (int)$this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }
    protected function _prepareCollection()
    {
		try{
			
			
			$collection =$this->_collectionFactory->load();

		  

			$this->setCollection($collection);

			parent::_prepareCollection();
		  
			return $this;
		}
		catch(Exception $e)
		{
			echo $e->getMessage();die;
		}
    }

    protected function _addColumnFilterToCollection($column)
    {
        if ($this->getCollection()) {
            if ($column->getId() == 'websites') {
                $this->getCollection()->joinField(
                    'websites',
                    'catalog_product_website',
                    'website_id',
                    'product_id=entity_id',
                    null,
                    'left'
                );
            }
        }
        return parent::_addColumnFilterToCollection($column);
    }

    protected function _prepareColumns()
    {
        $this->addColumn(
            'answers_id',
            array(
                'header' => __('Id'),
                //'type' => 'number',
                'index' => 'answers_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            )
        );
		 $this->addColumn(
            'created_at',
            array(
                'header' => __('Created'),
                'type' => 'datetime',
                'index' => 'created_at',
                'header_css_class' => 'col-date',
                'column_css_class' => 'col-date'
			)
        );
		$this->addColumn(
			'author_name',
			array(
			'header'    => __('Author Name'),
			'index'     => 'author_name',
			'class' => 'author_name'
			)
		);
		$this->addColumn(
			'author_email',
			array(
			'header'    => __('Author Mail'),
			'index'     => 'author_email',
			'class' => 'author_email'
			)
		);
		$this->addColumn(
		'answers',
			array(
			'header'    => __('Answers'),
			'index'     => 'answers',
			'class' => 'answers'
			)
		);
		$this->addColumn(
		'status',
			array(
			'header'    => __('Status'),
			'index'     => 'status',
			'type'      => 'options',
			'options'   => 
			array(
				"approved" => __('Approved'),
				"pendding" => __('Pending'),
			),
			)
		);
	/*	$this->addColumn(
            'action',
            [
                'header' => __('Action'),
                'type' => 'action',
                'getter' => 'getId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => [
                            'base' => 'question/answers/edit',
                            'params' => [
                                'productId' => $this->getProductId(),
                                'customerId' => $this->getCustomerId(),
                                //'ret' => $this->_coreRegistry->registry('usePendingFilter') ? 'pending' : null,
                            ],
                        ],
                        'field' => 'id',
                    ],
                ],
                'filter' => false,
                'sortable' => false
            ]
        );*/
		/*{{CedAddGridColumn}}*/

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

     /**
     * @return $this
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('answers_id');
        $this->getMassactionBlock()->setFormFieldName('answers_id');

        $this->getMassactionBlock()->addItem(
            'delete',
            array(
                'label' => __('Delete'),
                'url' => $this->getUrl('question/answers/massDelete'),
                'confirm' => __('Are you sure?')
            )
        );
        return $this;
    }

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('question/answers/index', ['_current' => true]);
    }

    public function getRowUrl($row)
    {
        return $this->getUrl(
            'question/answers/edit',
            ['store' => $this->getRequest()->getParam('store'), 'answers_id' => $row->getId()]
        );
    }
}
