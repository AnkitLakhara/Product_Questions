<?php

namespace Product\Questions\Block\Adminhtml\Answers\Edit\Tab;

/*use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;*/
//use Product\Questions\Model\Config\Source\QuestionList;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{

	protected $_systemStore;
//	protected $_questionList;
	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
//	\Product\Questions\Model\Config\Source\QuestionList $questionList;
        array $data = array()
    ) {
        $this->_systemStore = $systemStore;
//	$this->_questionList = $questionList;
        parent::__construct($context, $registry, $formFactory, $data);
    }
	
	protected function _prepareForm()
    {
		/* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('qa_product_answers');
		$isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Product Answers')));
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$que  = $objectManager->get('Product\Questions\Model\Questions')->getCollection();
		$questions[] = array(
			'value'     => '',
			'label'     => '--Please Select Question--',
		);
		foreach ($que as $item)
		{
		$questions[] = array(
		   'value'     => $item->getProductQuestionsId(),
		   'label'     => $item->getQuestions(),
		); 
		}
		
        if ($model->getId()) {
            $fieldset->addField('answers_id', 'hidden', array('name' => 'answers_id'));
        }
	
	$fieldset->addField(
            'product_questions_id',
            'select',
            array(
                'name' => 'product_questions_id',
                'values' => $questions,
                'label' => __('Select Questions'),
                'title' => __('Select Questions'),
                'required' => true,
		//'values' => $this->_questionlist->getOptionArray()
            )
        );
		
		$fieldset->addField(
            'status',
            'select',
            array(
                'name' => 'status',
                'label' => __('Status'),
                'title' => __('Status'),
                'required' => true,
		'options'   => 
			array(
				"approved" => __('Approved'),
				"pendding" => __('Pending'),
			),	
            )
        );
		$fieldset->addField(
            'author_name',
            'text',
            array(
                'name' => 'author_name',
                'label' => __('Author Name'),
                'title' => __('Author Name'),
                'required' => true,
            )
        );
		$fieldset->addField(
            'author_email',
            'text',
            array(
                'name' => 'author_email',
                'label' => __('Author Email'),
                'title' => __('Author Email'),
                'required' => true,
                'class' => 'validate-email',
            )
        );
		$fieldset->addField(
            'answers',
            'text',
            array(
                'name' => 'answers',
                'label' => __('Answers'),
                'title' => __('Answers'),
                'required' => true,
            )
        );
		$fieldset->addField(
            'created_at',
            'date',
            array(
                'name' => 'created_at',
                'label' => __('Created'),
                'title' => __('Created'),
                'date_format' => $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT),
                'time_format' => $this->_localeDate->getTimeFormat(\IntlDateFormatter::SHORT),
                'required' => true,
            )
        );
		/*{{CedAddFormField}}*/
        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? 'pending' : 'approved');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();   
    }
    public function getTabLabel()
    {
        return __('Answers Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Answers Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}

